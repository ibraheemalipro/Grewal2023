                  <table class="table">
<thead class="table-head">
<tr>
<th>Goods Type</th>
<th>5km To 20km</th>
<th>21km To 80km</th>
</tr>
</thead>
<tbody class="table-body">
<td>few boxes/Items</td>
<td>Rs 1,000 - 2,500</td>
<td>Rs. 1,200 - 4,500</td>
</tr>
<tr>
<td>1 RK</td>
<td>Rs 2,000 - 4,000</td>
<td>Rs. 2,500 - 6,000</td>
</tr>
<tr>
<td>1 BHK</td>
<td>Rs 2,500 - 5,000</td>
<td>Rs. 3,000 - 7,000</td>
</tr>
<tr>
<td>2 BHK</td>
<td>Rs 5,000 - 8,000</td>
<td>Rs. 6,00 - 14,000</td>
</tr>
</tbody>
</table>