                  <table class="table">
<thead class="table-head">
<tr>
<th>Office Type</th>
<th>Up to 15 Km</th>
<th>36+ Km</th>
</tr>
</thead>
<tbody class="table-body">
<td>Micro Office</td>
<td>Rs 7,000-13,000</td>
<td>₹ 9,000 - 21,500</td>
</tr>
<tr>
<td>Small Office</td>
<td>Rs 9,000 - 22,000</td>
<td>Rs 12,000 - 26,000</td>
</tr>
<tr>
<td>Medium</td>
<td>Rs 10,000 - 24,000</td>
<td>Rs 12,500 - 28,000</td>
</tr>
<tr>
<td>Standard Office</td>
<td>Rs 11,500 - 26,500</td>
<td>Rs. 15,000 - 35,000</td>
</tr>
</tbody>
</table>