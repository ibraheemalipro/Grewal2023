<table class="table">
<thead class="table-head">
<tr>
<th>Weight</th>
<th>Express</th>
<th>Economy</th>
</tr>
</thead>
<tbody class="table-body">
<td>3 Kg</td>
<td>Rs 150 - 250</td>
<td>Rs 100 - 200</td>
</tr>
<tr>
<td>5 Kg</td>
<td>Rs 250 - 350</td>
<td>Rs 200 - 300</td>
</tr>
<tr>
<td>25 Kg</td>
<td>Rs 700 - 950</td>
<td>Rs 650 - 750</td>
</tr>
<tr>
<td>50 Kg</td>
<td>Rs 1,100 - 1,450</td>
<td>Rs 950 - 1,250</td>
</tr>
</tbody>
</table>