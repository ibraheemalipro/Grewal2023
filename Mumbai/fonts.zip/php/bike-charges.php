<table class="table">
<thead class="table-head">
<tr>
<th>Bike Type</th>
<th>Within 10km To 500km</th>
<th>Within 500km To 1500km</th>
</tr>
</thead>
<tbody class="table-body">
<td>125cc To 150cc</td>
<td>Rs 4,000 - 7,000</td>
<td>Rs. 5,500 - 8,000</td>
</tr>
<tr>
<td>150cc To 200cc</td>
<td>Rs 5,000 - 7,000</td>
<td>Rs. 6,500 - 9,500</td>
</tr>
<tr>
<td>200 cc To 350 cc</td>
<td>Rs 5,000 - 9,000</td>
<td>Rs. 7,500 - 15,000</td>
</tr>
<tr>
<td>350cc To Above</td>
<td>Rs 5,000 - 8,000</td>
<td>Rs. 7,500 - 17,000</td>
</tr>
</tbody>
</table>