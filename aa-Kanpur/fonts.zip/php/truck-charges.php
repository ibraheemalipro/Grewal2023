<table class="table">
<thead class="table-head">
<tr>
<th>Truck Type</th>
<th>Wheel</th>
<th>Total charges</th>
</tr>
</thead>
<tbody class="table-body">
<td>16 Ton Truck</td>
<td>10 Wheel</td>
<td>Rs 7,500- 12,000</td>
</tr>
<tr>
<td>Eicher 19ft</td>
<td>6 Wheel</td>
<td>Rs 9,500- 14,000</td>
</tr>
<tr>
<td>32 feet multi axle</td>
<td>10 Wheel</td>
<td>Rs 12,000- 15,500</td>
</tr>
<tr>
<td>32 feet - 7 Ton</td>
<td>6 Wheel</td>
<td>Rs 14,500- 17,500</td>
</tr>
</tbody>
</table>