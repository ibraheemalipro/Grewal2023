<table class="table">
<thead class="table-head">
<tr>
<th>Car Type</th>
<th>Within 10km To 500km</th>
<th>Within 500km To 1500km</th>
</tr>
</thead>
<tbody class="table-body">
<td>Small Car</td>
<td>Rs 7,000 - 10,000</td>
<td>Rs. 10,000 - 15,000</td>
</tr>
<tr>
<td>Mini car</td>
<td>Rs 9,000 - 12,000</td>
<td>Rs. 10,500 - 18,000</td>
</tr>
<tr>
<td>XUV Car</td>
<td>Rs 10,000 - 17,000</td>
<td>Rs. 13,500 - 24,500</td>
</tr>
<tr>
<td>Large Car</td>
<td>Rs 10,000 - 19,000</td>
<td>Rs. 15,500 - 22,000</td>
</tr>
</tbody>
</table>