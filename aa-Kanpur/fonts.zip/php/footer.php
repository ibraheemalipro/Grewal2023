<footer>
<div class="container_fluid">
<div class="footer_area">
<div class="container">
	<div class="footer_logo"><a href="https://www.grewaltransportservice.com"><img alt="Grewal Transport logo"  src="https://imagedelivery.net/GszeG3iAQivExkh9MpZwAA/8ddb646d-73fb-4d31-ebd9-ac938265ec00/logo" width="300" height="70"></a></div>
	<div class="footer_sub_area">
<menu>Contact Us</menu>
<ul>
<li>24*7 customer support <a href="tel:09911076600"> +91 9911076600 </a></li>
	<li><a href="mailto:info@rehousingpackers.in">Mail : - info@grewaltransportservice.com</a></li>
	<li>Address : - Near Dwarka expressway, Daultabad industrial area, Daultabad, Sector 105, Gurugram, Haryana 122006</li>
</ul>
</div>
<div class="footer_sub_area">
<menu>Useful Links</menu>
<ul>
	<li><a href="https://www.grewaltransportservice.com/">Home</a></li>
	<li><a href="https://www.grewaltransportservice.com/vehicle-relocation.php">Vehicle Relocation</a></li>
	<li><a href="https://www.grewaltransportservice.com/International-services.php">International Relocation</a></li>
	<li><a href="https://www.grewaltransportservice.com/domestic-relocation.php">Domestic Relocation</a></li>
	<li><a href="https://www.grewaltransportservice.com/warehouse-services.php">Warehouse Services</a></li>
	<li><a href="https://www.grewaltransportservice.com/covid-19-transport-tips.php">Covid-19 Transport Tips</a></li>
</ul>
</div>
<div class="footer_sub_area">
<menu>Information From Blog</menu>
<ul>
	<li><a href="https://grewaltransportservice.com/privacy-policy.php">Privacy Policy</a></li>
	<li><a href="https://grewaltransportservice.com/disclaimer.php">Disclaimer</a></li>
	<li><a href="https://grewaltransportservice.com/terms-and-conditions.php">Terms and conditions</a></li>
	<li><a href="https://www.grewaltransportservice.com/sitemap.php">HTML sitemap</a></li>
		<li><a href="https://www.grewaltransportservice.com/sitemap.xml">XML sitemap</a></li>
	<li><a href="https://www.grewaltransportservice.com/clients.php">Clients</a></li>

</ul>
</div>
</div>
<div class="bottom_link"><div class="links_sol"><a class="social link_edin" href="https://in.linkedin.com/company/grewal-transport-service" target="_blank">linkedin</a> <a class="social twi_tter" href="https://twitter.com/TransportGrewal" target="_blank">twitter</a> <a class="social face_book" href="https://www.facebook.com/transportserviceingurgaondelhi/" target="_blank">facebook</a> <a class="social em_ail" href="mailto:info@grewaltransportservice.com" target="_blank">email</a></div></div>
</div>
</div>
<div class="container_fluid col_copy">
<div class="container">
<div class="copy_right_area">
<p>Copyrights &copy; 2021 Grewal Transport Service All Rights Reserved</p>
</div>
</div>
</div>
</footer>
<div class="fix-icon">
         <div class="fix-icon-item" id="fix-icon"><a href="tel:9911071177" target="blanck"><img alt="9911071177" src="https://imagedelivery.net/GszeG3iAQivExkh9MpZwAA/c2ec6442-2c44-424a-b65b-7d786b87ca00/phone" title="9911071177" width="40" height="40" /></a></div>
      </div>
      <div class="fix-icon-whataap">
         <div class="fix-icon-whataap-item" id="fix-icon-whataap"><a href="https://api.whatsapp.com/send?phone=+919911071177&amp;text=&amp;source=&amp;data=" target="blanck"><img alt="9911071177" src="https://imagedelivery.net/GszeG3iAQivExkh9MpZwAA/85814f41-dcbe-4828-7529-6073b6205600/phone" title="9911071177" width="50" height="50"/></a></div>
      </div>
     <div id="feedback">
			<a href="#Quote-For-Shift">Get FREE Quote</a>
		</div>
<a href="#" id="scroll" style="display: none;"><span></span></a>