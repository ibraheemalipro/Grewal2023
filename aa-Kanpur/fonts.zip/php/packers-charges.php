                  <table class="table">
<thead class="table-head">
<tr>
<th>Vehicle Type</th>
<th>5km To 50km</th>
<th>51km To 160km</th>
</tr>
</thead>
<tbody class="table-body">
<td>Pickup</td>
<td>Rs 8,00 - 1,900</td>
<td>Rs. 1,000 - 5,500</td>
</tr>
<tr>
<td>Tata Ace Chota Hathi</td>
<td>Rs 600 - 1,700</td>
<td>Rs. 800 - 5,500</td>
</tr>
<tr>
<td>Tata 407</td>
<td>Rs 1,100 - 2,400</td>
<td>Rs. 1,600 - 5,000</td>
</tr>
<tr>
<td>14 feet</td>
<td>Rs 1,500 - 3,500</td>
<td>Rs. 2,500 - 8,500</td>
</tr>
</tbody>
</table>