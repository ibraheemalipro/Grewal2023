 <div class="container_fluid">
      <div class="container">
                      <div class="table_area">
         <div class="form">
            <div class="contact_dtl">
                <h3>Are you looking for reliable goods transport services from Port Blair?</h3>
                <p>Here how it works</p>
               <ul>
                   <li>Goods transport services</li>
                   <li>Door to Door pick up & delivery</li>
                   <li>Express cargo transportation from across India by air, rail, or road</li>
                   <li>Regular shipment status tracking</li>
                   <li>Damage free delivery</li>
                   <li>Insurance of your consignment if required</li>
               </ul>
                           <img alt="Transport Services from Port Blair" src="https://imagedelivery.net/GszeG3iAQivExkh9MpZwAA/623eff14-0a53-4bb2-1d3c-ca0057d14400/charges" width="100%" height="300">
            </div>
 <div class="enquiry_form" id="Quote-For-Shift">
<div class="enquiry_dtl">
<h2 id="Quote-For-Shift-Noida" style="color: #fff;">Get Free Quote</h2>
<div class="fill_dtl">
<form  class="row" action="https://crm.rehousingpackers.in/api/insert.php"  method="POST">
                        <input type="text" name="name" id="first_name" class="form-control" placeholder="Name*" required/>
                        <input type="number" name="contactNo" id="phone" class="form-control" placeholder="Contact Number*" required/>
                        <input type="email" name="email" id="email" class="form-control" placeholder="Your Email"/> 
                            <select name="type[]" id="select_service" class="selectpicker form-control" data-style="btn-white"  multiple>
                             <option>Select Type*</option>    
                        <option>Household</option>
                        <option>Office</option>
                        <option>Two-Wheeler</option>
                        <option>Four-Wheeler</option>
                        </select>
                        <input type="date" name="moveDate" id="moving_from" class="form-control" required placeholder="Moving Date*" style="height:15px"/>
                        <input type="text" name="moveFrom" id="moving_from" class="form-control" placeholder="Pickup From*" required/>
                        <input type="text" name="moveTo" id="moving_to" class="form-control" required placeholder="Drop*"/>
                        
                        <input type="hidden" name="url" id="moving_to" class="form-control" value="<?php echo $link; ?>"/>
                       <!-- <input type="text" name="moving_date" id="moving_date" class="form-control" placeholder="Moving Date"/> -->
                        <textarea class="form-control" name="details" id="comments" rows="2" placeholder="Detail your moving items.."></textarea>
                        <button type="submit" value="SEND" id="submit" class="submit_btn" name="submit">Submit</button> 
                     </form>
                  </div>
               </div>
            </div>
      </div>
            </div>