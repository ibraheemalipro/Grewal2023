<table class="table">
<thead class="table-head">
<tr>
<th>Vehicle Type</th>
<th>Up To 500km</th>
<th>500km To 1500</th>
</tr>
</thead>
<tbody class="table-body">
<td>Pickup</td>
<td>Rs 9,000 - 12,000</td>
<td>Rs. 15,500 - 21,000</td>
</tr>
<tr>
<td>Tata Ace</td>
<td>Rs 5,000 - 11,000</td>
<td>Rs. 11,000 - 18,000</td>
</tr>
<tr>
<td>Tata 407</td>
<td>Rs 11,000 - 17,000</td>
<td>Rs. 16,500 - 24,500</td>
</tr>
<tr>
<td>14 feet</td>
<td>Rs 10,000 - 15,000</td>
<td>Rs. 18,500 - 22,000</td>
</tr>
</tbody>
</table>