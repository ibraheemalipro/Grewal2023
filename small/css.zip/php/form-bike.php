 <div class="container_fluid">
      <div class="container">
                      <div class="table_area">
         <div class="form">
            <div class="contact_dtl">
               <p>Tempo Travellers are more convenient than sedans for several reasons, including comfort, which is a top priority</p>
                           <ul>
                               <li>There is ample luggage space in the cabin</li>
                               <li>In the boot, there is a luggage compartment that is spacious</li>
                               <li>Young and old should have more leg room</li>
                               <li>No hassle adding more pickup points and stops</li>
                               <li>The provision of an audio system</li>
                               <li>Alternatives to air conditioning</li>
                               <li>Comfortable seating space and well-planned aisles</li>
                               <li>Providing reliable service</li>
                               <li>A courteous and punctual driver</li>
                               <li>Verified and clean vehicles</li>
                               <li>There are no hidden charges and transparency in billing</li>
                               <li>Vehicles with superior engines are stable online thanks to Benz, Force, and Mahindra</li>
                           </ul>
                           <p>Our packers and movers company can make the difference whether you are moving a small business, an office, or a large industrial unit.</p>
                           <img alt="What are the benefits you get when you hire our tempo transport service?" src="https://www.grewaltransportservice.com/small/img/new/local-tempo-for-shifting.webp" width="100%" height="300">
            </div>
 <div class="enquiry_form" id="Quote-For-Shift">
<div class="enquiry_dtl">
<h2 id="Quote-For-Shift-Noida" style="color: #fff;">Get Free Quote For Shift Your Goods</h2>
<div class="fill_dtl">
<form  class="row" action="https://crm.rehousingpackers.in/api/insert.php"  method="POST">
                        <input type="text" name="name" id="first_name" class="form-control" placeholder="Name*" required/>
                        <input type="number" name="contactNo" id="phone" class="form-control" placeholder="Contact Number*" required/>
                        <input type="email" name="email" id="email" class="form-control" placeholder="Your Email"/> 
                        <select name="quality" id="select_service" class="selectpicker form-control" data-style="btn-white" >
                            <option value=""> Select Quality*</option>
                           <option>Expensive goods upper Quality</option>
                        <option>Average quality Local & national</option>
                        <option>Low quality only Local shifting</option>
                       
                        </select>
                            <select name="type[]" id="select_service" class="selectpicker form-control" data-style="btn-white"  multiple>
                             <option>Select Type*</option>    
                        <option>Household</option>
                        <option>Office</option>
                        <option>Two-Wheeler</option>
                        <option>Four-Wheeler</option>
                        </select>
                         
                        <input type="date" name="moveDate" id="moving_from" class="form-control" required placeholder="Moving Date*" style="height:15px"/>
                      
                        <input type="text" name="moveFrom" id="moving_from" class="form-control" placeholder="Pickup From*" required/>
                        <input type="text" name="moveTo" id="moving_to" class="form-control" required placeholder="Drop*"/>
                        
                        <input type="hidden" name="url" id="moving_to" class="form-control" value="<?php echo $link; ?>"/>
                       <!-- <input type="text" name="moving_date" id="moving_date" class="form-control" placeholder="Moving Date"/> -->
                        <textarea class="form-control" name="details" id="comments" rows="2" placeholder="Detail your moving items.."></textarea>
                        <button type="submit" value="SEND" id="submit" class="submit_btn" name="submit">Submit</button> 
                     </form>
                  </div>
               </div>
            </div>
      </div>
            </div>