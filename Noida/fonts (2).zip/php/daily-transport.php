                  <table class="table">
<thead class="table-head">
<tr>
<th>Service Type</th>
<th>Timing</th>
<th>Charges</th>
</tr>
</thead>
<tbody class="table-body">
<td>Commercial Transport</td>
<td>07:00 PM</td>
<td>Rs. 3,000 - 14,500</td>
</tr>
<tr>
<td>Furniture and Household</td>
<td>04:00 PM</td>
<td>Rs. 3,000 - 9,500</td>
</tr>
<tr>
<td>Road Carrier</td>
<td>09:00 PM</td>
<td>Rs. 21,600 - 30,000</td>
</tr>
<tr>
<td>Pet transport</td>
<td>09:00 AM</td>
<td>Rs. 2,500 - 11,500</td>
</tr>
</tbody>
</table>