<footer>
<div class="container_fluid">
<div class="footer_area">
<div class="container">
	<div class="footer_logo"><a href="https://www.rehousingpackers.in"><img alt="Rehousing packers" longdesc="#" src="images/rehouse_logo.png" width="300" height="70"></a></div>
	<div class="footer_sub_area">
<menu>Contact Us</menu>

<ul>
	<li>24*7 customer support <a href="tel:09911071177"> 09911071177 </a> <a href="tel:09911076600"> Call 09911076600</a></li>
	<li><a href="mailto:info@rehousingpackers.in">Mail Now</a></li>
	<li>Address : -  Near Dwarka expressway, Daultabad industrial area, Daultabad, Sector 105, Gurugram, Haryana 122006</li>
</ul>
</div>
<div class="footer_sub_area">
<menu>Useful Links</menu>
<ul>
	<li><a href="https://www.rehousingpackers.in/services/packing-and-moving.php">Packing and Moving</a></li>
	<li><a href="https://www.rehousingpackers.in/services/vehicle-transport.php">Vehicle Transport</a></li>
	<li><a href="https://www.rehousingpackers.in/services/international-relocation.php">International Relocation</a></li>
	<li><a href="https://www.rehousingpackers.in/services/employee-relocation.php">Employee Relocation</a></li>
		<li><a href="https://www.rehousingpackers.in/sitemap.html">HTML Sitemap</a></li>
	<li><a href="https://www.rehousingpackers.in/sitemap.xml">XML Sitemap</a></li>
</ul>
</div>
<div class="footer_sub_area">
<menu>Information From Blog</menu>
<ul>
	<li><a href="https://www.rehousingpackers.in/blog/packing-tips.php">Packing tips</a></li>
	<li><a href="https://www.rehousingpackers.in/blog/moving-tips.php">Tips for moving</a></li>
	<li><a href="https://www.rehousingpackers.in/blog/protect-your-furniture-wooden-accessories-during-relocation.php">Protect your furniture</a></li>
		<li><a href="https://www.rehousingpackers.in/india/">Know About India</a></li>
</ul>
</div>
</div>
<div class="bottom_link"><a href="https://www.rehousingpackers.in/terms-and-conditions.php">Terms and Conditions</a> <a href="https://www.rehousingpackers.in/privacy-policy.php">privacy policy</a> <a href="https://www.rehousingpackers.in/disclaimer.php">Disclaimer</a><div class="links_sol"><a class="social link_edin" href="https://in.linkedin.com/in/rehousing-packers-4000b81b7" target="_blank">linkedin</a> <a class="social twi_tter" href="https://twitter.com/packersre" target="_blank">twitter</a> <a class="social face_book" href="https://www.facebook.com/Rehousingpackerscom-106915621181660/" target="_blank">facebook</a> <a class="social em_ail" href="mailto:rehousingpackers@gmail.com" target="_blank">email</a></div></div>
</div>
</div> 
<div class="container_fluid col_copy">
<div class="container">
<div class="copy_right_area">
<p>Copyrights &copy; 2021 Rehousing Packers All Rights Reserved</p>
</div>
</div>
</div>
</footer>
<div class="fix-icon">
         <div class="fix-icon-item" id="fix-icon"><a href="tel:9911071177" target="blanck"><img alt="9911071177" src="image/phone-icon.webp" title="9911071177" /></a></div>
      </div>
      <div class="fix-icon-whataap">
         <div class="fix-icon-whataap-item" id="fix-icon-whataap"><a href="https://api.whatsapp.com/send?phone=+919911071177&amp;text=&amp;source=&amp;data=" target="blanck"><img alt="9911071177" src="image/whatsapp.svg" title="9911071177" /></a></div>
      </div>
     <div id="feedback">
			<a href="#Quote-For-Shift">Get FREE Quote</a>
		</div>
<a href="#" id="scroll" style="display: none;"><span></span></a>