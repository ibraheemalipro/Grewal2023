<header>
<div class="container_fluid">
<div class="container">
<div class="logo_area">
<div class="logo"><a href="https://www.rehousingpackers.in" title="Rehousing packers logo"><img alt="Rehousing packers logo" longdesc="#" src="img/rehousing-logo.png" title="Rehousing packers and movers" width="100%" height="100"></a></div>
</div>
</div>
<div class="container_fluid">
<div class="container">
<div class="topnav" id="myTopnav"><button class="mobile_menu">menu</button>
	<div id="mobile_navigation">
	<ul>
		<li><a class="active" href="https://www.rehousingpackers.in/">Home</a></li>
		<li><a href="https://www.rehousingpackers.in/about-us.php">About Us</a></li>
		<li><a href="https://www.rehousingpackers.in/packers-and-movers-bill-for-claim.php">Bill for Claim</a></li>
		<li><a href="https://www.rehousingpackers.in/faq-frequently-asked-questions.php">FAQ?</a></li>
		<li><a href="https://www.rehousingpackers.in/blog/">Blog</a></li>
		<li class="serv"><a href="https://www.rehousingpackers.in/services/">Service</a></li>
		<li><a href="https://www.rehousingpackers.in/contact-us.php">Contact Us</a></li>
	</ul>
	    </div>
	</div>
</div>
</div>
	<script>
				jQuery('#myTopnav .mobile_menu').click(function(){
				   jQuery('#mobile_navigation').slideToggle()
				   return false
				 })
			</script>
</header>
<div class="container_fluid">
         <div class="top_banner"><img alt="Rehousing Packers" src="images/banner_small.png" width="100%" height="170" ></div>
                  <div class="container">
            <div class="banner_dtl">
            </div>
         </div>
      </div>